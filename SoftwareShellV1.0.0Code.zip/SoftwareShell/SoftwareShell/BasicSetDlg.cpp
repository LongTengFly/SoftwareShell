// BasicSetDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SoftwareShell.h"
#include "BasicSetDlg.h"
#include "afxdialogex.h"

#include "SetParameter.h"
#include "SleeperParameter.h"

CString strListSWName[SOFTWARENUM];
CString strListSWPath[SOFTWARENUM];

// CBasicSetDlg �Ի���
extern BOOL bool_StartTest;
extern BOOL bool_initTest;
extern CTabCtrl c_mTab;;
extern CString cstr_pathCurrentDir;

IMPLEMENT_DYNAMIC(CBasicSetDlg, CDialogEx)

CBasicSetDlg::CBasicSetDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CBasicSetDlg::IDD, pParent)
{

	m_nSelItem = 0;
}

CBasicSetDlg::~CBasicSetDlg()
{
}

void CBasicSetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_LEVEL, c_listLevel);
}


BEGIN_MESSAGE_MAP(CBasicSetDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BTN_REMOVE, &CBasicSetDlg::OnBnClickedBtnRemove)
	ON_BN_CLICKED(IDC_BTN_RESET, &CBasicSetDlg::OnBnClickedBtnReset)
	ON_BN_CLICKED(IDC_BTN_STARTTEST, &CBasicSetDlg::OnBnClickedBtnStarttest)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_LEVEL, &CBasicSetDlg::OnNMDblclkList1)
	ON_NOTIFY(LVN_BEGINDRAG, IDC_LIST_LEVEL, &CBasicSetDlg::OnLvnBegindrag)
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
END_MESSAGE_MAP()


// CBasicSetDlg ��Ϣ��������

int GetInstallSoftwareByReg(LPCTSTR lpSubKey)
{
	//LPCTSTR lpSubKey;
	int softwareNum = 0;
	int i;
	HKEY hKey;
	DWORD index = 0;
	TCHAR szKeyName[255] = { 0 };
	TCHAR szBuffer[255] = { 0 };
	DWORD dwKeyLen = 255;
	CString strBuffer;
	CString strMidReg;
	HKEY hkRKey;
	DWORD dwNameLen = 255;
	//////////////////////////////
	DWORD dwType = REG_BINARY | REG_DWORD | REG_EXPAND_SZ | REG_MULTI_SZ | REG_NONE | REG_SZ;
	//lpSubKey = _T("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall");
	//HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\BurnInTest_is1
	int ret = RegOpenKeyEx(HKEY_LOCAL_MACHINE, lpSubKey, 0, KEY_READ, &hKey);
	if (ret == ERROR_SUCCESS)
	{
		while (ERROR_NO_MORE_ITEMS != RegEnumKeyEx(hKey, index, szKeyName, &dwKeyLen, 0, NULL, NULL, NULL))
		{
			index++;
			strBuffer.Format(_T("%s"), szKeyName);
			if (!strBuffer.IsEmpty())
			{
				strMidReg = (CString)lpSubKey + _T("\\") + strBuffer;
				if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, strMidReg, 0, KEY_READ, &hkRKey) == ERROR_SUCCESS)
				{
					RegQueryValueEx(hkRKey, _T("DisplayName"), 0, &dwType, (LPBYTE)szBuffer, &dwNameLen);
					if (StrStr(szBuffer, TEXT("BurnInTest")))
					{
						//InstallLocation
						softwareNum += 1;
						//TIS_Trace(TEXT("%03d software Name:%s\n"), index, szBuffer);
						dwNameLen = 255;
						memset(szBuffer, 0, 255);
						RegQueryValueEx(hkRKey, _T("InstallLocation"), 0, &dwType, (LPBYTE)szBuffer, &dwNameLen);
						for (i = 0; i < SOFTWARENUM; i++)
						{
							if (StrStr(strListSWName[i], TEXT("BurnInTest")))
							{
								strListSWPath[i] = szBuffer;
								strListSWPath[i].Append(L"bit.exe");
							}

						}
					}
					else if (StrStr(szBuffer, TEXT("3DMark")))
					{
						softwareNum += 2;
						//TIS_Trace(TEXT("%03d software Name:%s\n"), index, szBuffer);
					}
						
					dwNameLen = 255;
					memset(szBuffer, 0, 255);
				}
			}
			dwKeyLen = 255;
			memset(szKeyName, 0, 255);
		}
		
	}
	else
		MessageBox(NULL, _T("��ע���ʧ��!"), NULL, MB_ICONWARNING);
	RegCloseKey(hKey);
	return softwareNum;
}
BOOL CBasicSetDlg::UpdataListName(CString *strList,UINT ItemNum)
{
	UINT i;
	CString cstr_levelNum;
	for (i = 0; i < ItemNum;i++)
	{
		cstr_levelNum.Format(L"%02d",i+1);
		//c_listLevel.InsertItem(i, cstr_levelNum);
		c_listLevel.SetItemText(i, 0,cstr_levelNum);
		c_listLevel.SetItemText(i, 1, strList[i]);
	}
	UpdateData();

	return TRUE;
}
//isTop=0,moveUp=1,moveDown=2,remove=3,reset=4;
//void CBasicSetDlg::SetSoftwareLevel(UINT OperationID)
void CBasicSetDlg::SetSoftwareLevel(int curItemId,const int firstSelItemId)
{
	if (curItemId == -1 || curItemId == firstSelItemId)
		return;
	int i, mItemCount,mFirstItemId;
	CString strList_name[SOFTWARENUM];
	CString str_path;
	mFirstItemId = firstSelItemId;
	mItemCount = c_listLevel.GetItemCount();
	for (i = 0; i < mItemCount; i++)
		strList_name[i] = c_listLevel.GetItemText(i, 1);
	str_path = strListSWPath[mFirstItemId];
	if (curItemId < firstSelItemId)
	{
		while (mFirstItemId>curItemId)
		{
			//TIS_Trace(TEXT("SWPath:%s\n"), strListSWPath[i]);
			strListSWPath[mFirstItemId] = strListSWPath[mFirstItemId - 1];
			strList_name[mFirstItemId] = strList_name[mFirstItemId - 1];
			mFirstItemId--;
		}
	}
	else
	{
		while (mFirstItemId<curItemId)
		{
			strList_name[mFirstItemId] = strList_name[mFirstItemId + 1];
			strListSWPath[mFirstItemId] = strListSWPath[mFirstItemId + 1];
			mFirstItemId++;
		}
		
	}
	strListSWPath[curItemId] = str_path;
	strList_name[curItemId] = c_listLevel.GetItemText(firstSelItemId, 1);
	c_listLevel.SetItemState(curItemId, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
	c_listLevel.SetItemState(firstSelItemId, 0, LVIS_SELECTED | LVIS_FOCUSED);
	UpdataListName(strList_name, mItemCount);
	for (i = 0; i < mItemCount; i++)
	{
		strListSWName[i] = strList_name[i];
	}
	c_listLevel.SetFocus();
}
BOOL CBasicSetDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	CRect listRect;//�б��ؼ���ȡ
	CString cstr_getPriority;
	CString cstr_itemStr;
	int i, nId;
	CString strInitSWName[SOFTWARENUM] = { L"BurnInTest", L"3DMark", L"Sleeper", L"StartMemTest" };
	
	c_listLevel.GetClientRect(&listRect);
	c_listLevel.SetExtendedStyle(c_listLevel.GetExtendedStyle() | LVS_EX_FULLROWSELECT );//| LVS_EX_GRIDLINES);
	
	c_listLevel.InsertColumn(0, _T("Level"), LVCFMT_CENTER, listRect.Width()/5, 0);
	c_listLevel.InsertColumn(1, _T("Software Name"), LVCFMT_CENTER, 4*listRect.Width() / 5, 1);
	
	c_listLevel.DeleteAllItems();
	for (i = 0; i < SOFTWARENUM;i++)
	{
		cstr_getPriority.Format(L"%02d", i + 1);
		c_listLevel.InsertItem(0, cstr_getPriority);

		cstr_itemStr.Format(L"Level%d",i+1);
		::GetPrivateProfileString(SW_PRIORITY, cstr_itemStr, strInitSWName[i], cstr_getPriority.GetBuffer(MAX_PATH), MAX_PATH, SW_CONFIG);
		strListSWName[i] = cstr_getPriority;
		cstr_getPriority.ReleaseBuffer();
		/*
		*get software path.
		*Modify here when there is an update.
		*/
		::GetPrivateProfileString(SW_PATH, strListSWName[i], L".//error.txt", cstr_getPriority.GetBuffer(MAX_PATH), MAX_PATH, SW_CONFIG);
		if (StrStr(cstr_getPriority, L"error.") != NULL && StrStr(strListSWName[i], L"3DMark") != NULL)
			strListSWPath[i] = L"C:\\Program Files\\Futuremark\\3DMark\\3DMarkCmd.exe";
		else if (StrStr(cstr_getPriority, L"error.") != NULL && StrStr(strListSWName[i], L"Sleeper") != NULL)
			strListSWPath[i] = cstr_pathCurrentDir + L"\\Sleeper\\Sleeper.exe";
		else if (StrStr(cstr_getPriority, L"error.") != NULL && StrStr(strListSWName[i], L"StartMemTest") != NULL)
			strListSWPath[i] = cstr_pathCurrentDir + L"\\StartMemTest\\StartMemTest.exe";
		else
			strListSWPath[i] = cstr_getPriority;
		cstr_getPriority.ReleaseBuffer();
	}
	UpdataListName(strListSWName,SOFTWARENUM);
	
	//check software
	switch (GetInstallSoftwareByReg(_T("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall")))
	{
		case 0://No software installed or failed to open registry
			for (i = 0; i < 2; i++)
			{
				for (nId = 0; nId < c_listLevel.GetItemCount(); nId++)
				{
					cstr_itemStr = c_listLevel.GetItemText(nId, 1);
					if (StrStr(cstr_itemStr, L"BurnInTest") != NULL || StrStr(cstr_itemStr, L"3DMark") != NULL)
					{
						RemoveListItem(nId);
						break;
					}
				}

			}
			break;
		case 1://Only BurnInTest installed
			for (nId = 0; nId < c_listLevel.GetItemCount(); nId++)
			{
				cstr_itemStr = c_listLevel.GetItemText(nId, 1);
				if (StrStr(cstr_itemStr, L"3DMark") != NULL)
				{
					RemoveListItem(nId);
					break;
				}
			}
			break;
		case 2://Only 3DMark installed
			for (nId = 0; nId < c_listLevel.GetItemCount(); nId++)
			{
				cstr_itemStr = c_listLevel.GetItemText(nId, 1);
				if (StrStr(cstr_itemStr, L"BurnInTest") != NULL)
				{
					RemoveListItem(nId);
					break;
				}
			}
			break;
		//case 3://All installed
			//::GetPrivateProfileString(SW_PRIORITY, L"First", L"BurnInTest", cstr_itemStr.GetBuffer(MAX_PATH), MAX_PATH, SW_CONFIG);
			//TIS_Trace(TEXT("cfg:%s\n"),cstr_itemStr);
			//break;
		default:
			break;
	}
	::GetPrivateProfileString(SW_PATH, L"Sleeper", cstr_pathCurrentDir + L"\\Sleeper\\Sleeper.exe", cstr_getPriority.GetBuffer(MAX_PATH), MAX_PATH, SW_CONFIG);
	cstr_getPriority.ReleaseBuffer();
	if (!PathFileExists(cstr_getPriority))
	{
		for (nId = 0; nId < c_listLevel.GetItemCount(); nId++)
		{
			cstr_itemStr = c_listLevel.GetItemText(nId, 1);
			if (StrStr(cstr_itemStr, L"Sleeper") != NULL)
			{
				RemoveListItem(nId);
				break;
			}
		}
	}
	::GetPrivateProfileString(SW_PATH, L"StartMemTest", cstr_pathCurrentDir + L"\\StartMemTest\\StartMemTest.exe", cstr_getPriority.GetBuffer(MAX_PATH), MAX_PATH, SW_CONFIG);
	cstr_getPriority.ReleaseBuffer();
	if (!PathFileExists(cstr_getPriority))
	{
		for (nId = 0; nId < c_listLevel.GetItemCount(); nId++)
		{
			cstr_itemStr = c_listLevel.GetItemText(nId, 1);
			if (StrStr(cstr_itemStr, L"StartMemTest") != NULL)
			{
				RemoveListItem(nId);
				break;
			}
		}
	}
	if (!PathFileExists(cstr_pathCurrentDir + L"\\Rebooter\\rebooter.exe"))
	{
		((CButton *)GetDlgItem(IDC_CHECK_REBOOTER))->EnableWindow(0);
		((CButton *)GetDlgItem(IDC_CHECK_REBOOTER))->SetCheck(FALSE);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_REBOOTER))->EnableWindow(1);
		((CButton *)GetDlgItem(IDC_CHECK_REBOOTER))->SetCheck(::GetPrivateProfileInt(SW_PARAMETER, L"RunRebooter", 0, SW_CONFIG));
	}
	//goods(_T("SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall"));
	bool_StartOrStop = FALSE;
	
	/*
	//�ƶ����ڵ���Ļ���½�
	CRect rectDeskArea, rectDlg;
	SystemParametersInfo(SPI_GETWORKAREA, 0, &rectDeskArea, SPIF_SENDCHANGE);
	GetWindowRect(&rectDlg);
	::SetWindowPos(GetSafeHwnd(), HWND_BOTTOM, rectDeskArea.left, rectDeskArea.bottom - rectDlg.Height(), rectDlg.Width(), rectDlg.Height(), SWP_NOZORDER);
	this->SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);//ʹ������������ǰ��
	*/
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣:  OCX ����ҳӦ���� FALSE
}

void CBasicSetDlg::RemoveListItem(int Id)
{
	int nHeadNum, i;
	CString strList_name[SOFTWARENUM];
	CString cstr_itemStr;
	cstr_itemStr = c_listLevel.GetItemText(Id, 1);
	c_listLevel.DeleteItem(Id);
	nHeadNum = c_listLevel.GetItemCount();
	for (i = 0; i < nHeadNum; i++)
		strList_name[i] = c_listLevel.GetItemText(i, 1);
	strList_name[nHeadNum] = cstr_itemStr;
	UpdataListName(strList_name, nHeadNum);

	for (i = 0; i < nHeadNum; i++)
	{
		strListSWName[i] = strList_name[i];
	}
	strListSWName[nHeadNum] = cstr_itemStr;

	cstr_itemStr = strListSWPath[Id];
	for (i = Id; i < nHeadNum; i++)
		strListSWPath[i] = strListSWPath[i+1];
	strListSWPath[nHeadNum] = cstr_itemStr;
}

void CBasicSetDlg::OnBnClickedBtnRemove()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	//���ȵõ������λ�� 
	int nId;
	//CString strList_name[SOFTWARENUM];
	//CString cstr_itemStr;
	POSITION pos = c_listLevel.GetFirstSelectedItemPosition();
	if (pos == NULL)
	{
		MessageBox(L"������ѡ��һ��", L"SoftwareShell", MB_ICONEXCLAMATION);
		return;
	}
	//�õ��кţ�ͨ��POSITIONת�� 
	nId = (int)c_listLevel.GetNextSelectedItem(pos);
	RemoveListItem(nId);
	
}


void CBasicSetDlg::OnBnClickedBtnReset()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	//c_listLevel.DeleteAllItems();
	c_listLevel.DeleteColumn(0);
	c_listLevel.DeleteColumn(0);
	/*
	UINT i;
	CString cstr_levelNum;
	for (i = 0; i < SOFTWARENUM; i++)
	{
		cstr_levelNum.Format(L"%02d", i + 1);
		c_listLevel.InsertItem(i, cstr_levelNum);
	}
	UpdataListName(strListSWName,SOFTWARENUM);
	*/
	OnInitDialog();
}


void CBasicSetDlg::OnBnClickedBtnStarttest()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	int i;
	CString cstr_temp;
	CString cstr_logfileName;
	CRect rectDeskArea, rectDlg;
	extern HWND hMainDlg;
	bool_StartOrStop = !bool_StartOrStop;
	if (bool_StartOrStop)
	{
		SetDlgItemTextW(IDC_BTN_STARTTEST, L"ֹͣ���");
		//write to config
		for (i = 0; i < SOFTWARENUM; i++)
		{
			cstr_temp.Format(L"Level%d",i+1);
			::WritePrivateProfileString(SW_PRIORITY, cstr_temp, strListSWName[i], SW_CONFIG);
			::WritePrivateProfileString(SW_PATH, strListSWName[i], strListSWPath[i], SW_CONFIG);
		}
		if (((CButton *)GetDlgItem(IDC_CHECK_REBOOTER))->GetCheck())
			::WritePrivateProfileString(SW_PARAMETER, L"RunRebooter", L"1", SW_CONFIG);
		else
			::WritePrivateProfileString(SW_PARAMETER, L"RunRebooter", L"0", SW_CONFIG);
		//��ؿ�ʼ����
		bool_StartTest = TRUE;
		bool_initTest = TRUE;
		//�ƶ����ڵ���Ļ���½�
		SystemParametersInfo(SPI_GETWORKAREA, 0, &rectDeskArea, SPIF_SENDCHANGE);
		::GetWindowRect(hMainDlg, &rectDlg);
		::SetWindowPos(hMainDlg, HWND_BOTTOM, rectDeskArea.left, rectDeskArea.bottom - rectDlg.Height(), rectDlg.Width(), rectDlg.Height(), SWP_NOZORDER);
		//rename
		i = 1;
		if (PathIsDirectory(cstr_pathCurrentDir + L"\\LogFile"))//�ж�·���Ƿ����
		{
			cstr_logfileName.Format(L"%s\\LogFile%d", cstr_pathCurrentDir,i);
			while (PathIsDirectory(cstr_logfileName)&&i<100)
			{
				i++;
				cstr_logfileName.Format(L"%s\\LogFile%d", cstr_pathCurrentDir, i);
			}
			if (i<100)
				MoveFile(cstr_pathCurrentDir + L"\\LogFile", cstr_logfileName);
		}
		//c_mTab.SetCurSel(1);
		NMHDR   nmhdr;
		nmhdr.code = TCN_SELCHANGE;
		nmhdr.hwndFrom = c_mTab.GetSafeHwnd();
		nmhdr.idFrom = c_mTab.GetDlgCtrlID();
		::SendMessage(::GetDlgItem(AfxGetApp()->GetMainWnd()->GetSafeHwnd(), IDC_TAB1), TCM_SETCURSEL, 01, NULL);
		::SendMessage(::GetDlgItem(AfxGetApp()->GetMainWnd()->GetSafeHwnd(), IDC_TAB1), WM_NOTIFY, MAKELONG(TCN_SELCHANGE, 1), (LPARAM)(&nmhdr));
	}
	else 
	{
		//ֹͣ����
		bool_StartTest = FALSE;
		bool_initTest = FALSE;
		SetDlgItemTextW(IDC_BTN_STARTTEST, L"��ʼ����");
	}

	//pDialog[0]->ShowWindow(SW_HIDE);  
	//pDialog[1]->ShowWindow(SW_SHOW);
}

void CBasicSetDlg::OnNMDblclkList1(NMHDR *pNMHDR, LRESULT *pResult)

{

	//LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	POSITION pos = c_listLevel.GetFirstSelectedItemPosition();
	//�õ��кţ�ͨ��POSITIONת�� 
	int nId = (int)c_listLevel.GetNextSelectedItem(pos);
	if (StrStr(c_listLevel.GetItemText(nId, 1), L"3DMark"))
	{
		CSetParameter dlgSetParameter;
		dlgSetParameter.DoModal();
	}
	else if (StrStr(c_listLevel.GetItemText(nId, 1), L"Sleeper"))
	{
		CSleeperParameter dlgSleeperParameter;
		dlgSleeperParameter.DoModal();
	}
	else if (StrStr(c_listLevel.GetItemText(nId, 1), L"StartMemTest"))
	{
		::WritePrivateProfileString(L"CONFIG", L"AUTOTEST", L"0", cstr_pathCurrentDir + L"\\StartMemTest\\OpenMemTS.ini");
		ShellExecute(NULL, L"open", strListSWPath[nId], NULL, NULL, SW_SHOWNA);
	}
	else if ((int)ShellExecute(NULL, L"open", strListSWPath[nId], NULL, NULL, SW_SHOWNA) <= 32)
		MessageBox(L"��������ʧ�ܣ�", L"SoftwareShell", MB_ICONERROR);
	*pResult = 0;

}
//��קЧ��
void CBasicSetDlg::OnLvnBegindrag(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	*pResult = 0;
	int count = c_listLevel.GetSelectedCount();
	if (1 != count)
		return;
	POSITION pos = c_listLevel.GetFirstSelectedItemPosition();
	if (NULL == pos)
		return;
	//��ȡitem
	m_nSelItem = c_listLevel.GetNextSelectedItem(pos);
	if (-1 == m_nSelItem)
		return;
	CPoint pt = pNMLV->ptAction;
	m_pDragImageList = c_listLevel.CreateDragImage(m_nSelItem, &pt);
	if (NULL == m_pDragImageList)
		return;
	m_bDragging = TRUE;
	m_pDragImageList->BeginDrag(0, CPoint(8, 8));
	ClientToScreen(&pt);
	CRect rt;
	GetParent()->GetWindowRect(&rt);
	pt.x -= rt.left;
	pt.y -= rt.top;
	m_pDragImageList->DragEnter(GetParent(), pt);
	SetCapture();
}


void CBasicSetDlg::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO:  �ڴ�������Ϣ������������/�����Ĭ��ֵ
	if (m_bDragging)
	{
		ReleaseCapture();
		m_bDragging = FALSE;
		m_pDragImageList->DragLeave(GetParent());
		m_pDragImageList->EndDrag();
		m_pDragImageList->DeleteImageList();
		delete m_pDragImageList;
		m_pDragImageList = NULL;
		/*
		*�ƶ�item
		*/
		CPoint  mPoint;
		LVHITTESTINFO info;

		GetCursorPos(&mPoint);
		//����Ļ����ת���ͻ�������
		c_listLevel.ScreenToClient(&mPoint);  
		info.pt = mPoint;
		c_listLevel.SubItemHitTest(&info);
		//nId = info.iItem;//�кŴ�0��ʼ
		SetSoftwareLevel(info.iItem, m_nSelItem);
	}
	CDialogEx::OnLButtonUp(nFlags, point);
}


void CBasicSetDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO:  �ڴ�������Ϣ������������/�����Ĭ��ֵ
	if (m_bDragging)
	{
		CPoint pt = point;
		ClientToScreen(&pt);
		CRect rt;
		GetParent()->GetWindowRect(&rt);
		pt.x -= rt.left;
		pt.y -= rt.top;
		m_pDragImageList->DragMove(pt);
	}
	CDialogEx::OnMouseMove(nFlags, point);
}
