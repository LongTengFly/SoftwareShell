#pragma once


// CSleeperParameter �Ի���

class CSleeperParameter : public CDialogEx
{
	DECLARE_DYNAMIC(CSleeperParameter)

public:
	CSleeperParameter(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CSleeperParameter();

// �Ի�������
	enum { IDD = IDD_DLG_SLEEPBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
};
