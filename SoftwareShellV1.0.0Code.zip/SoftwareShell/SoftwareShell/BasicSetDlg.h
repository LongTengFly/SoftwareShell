#pragma once
#include "afxcmn.h"

#define ID_ISTOP	0
#define ID_MOVEUP	1
#define ID_MOVEDOWN	2
// CBasicSetDlg �Ի���

class CBasicSetDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CBasicSetDlg)

public:
	CBasicSetDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBasicSetDlg();

// �Ի�������
	enum { IDD = IDD_BASICSET_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CListCtrl c_listLevel;
	virtual BOOL OnInitDialog();
	//afx_msg void OnBnClickedBtnIstop();
	BOOL CBasicSetDlg::UpdataListName(CString *strList, UINT ItemNum);
	void CBasicSetDlg::RemoveListItem(int Id);
	//afx_msg void OnBnClickedBtnMoveup();
	//void CBasicSetDlg::SetSoftwareLevel(UINT OperationID);
	void CBasicSetDlg::SetSoftwareLevel(int curItemId, const int firstSelItemId);
	//afx_msg void OnBnClickedBtnMovedown();
	afx_msg void OnBnClickedBtnRemove();
	afx_msg void OnBnClickedBtnReset();
	afx_msg void OnBnClickedBtnStarttest();
	afx_msg void OnNMDblclkList1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnLvnBegindrag(NMHDR *pNMHDR, LRESULT *pResult);
	BOOL bool_StartOrStop;
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	CImageList* m_pDragImageList;
	BOOL m_bDragging;
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	int m_nSelItem;
};
