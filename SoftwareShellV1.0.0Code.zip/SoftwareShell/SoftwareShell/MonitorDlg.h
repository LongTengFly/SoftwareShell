#pragma once
#include "afxcmn.h"
#include "BasicSetDlg.h"
#include "afxwin.h"

// CMonitorDlg �Ի���

class CMonitorDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CMonitorDlg)

public:
	CMonitorDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMonitorDlg();

// �Ի�������
	enum { IDD = IDD_MONITOR_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CListCtrl c_list_testprog;
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	BOOL CMonitorDlg::SearchApplication(CString SWName, UINT LevelNum);
	BOOL CMonitorDlg::ResultDetection(CString SWName);
	BOOL bool_startMonitor;
	CString cstr_get3DMarkCycle;
	CString str_currentTime;
	UINT uint_ExecutionNum;
	CEdit c_edit_counter;
	int int_counter;
};
