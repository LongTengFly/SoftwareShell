// MonitorDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SoftwareShell.h"
#include "MonitorDlg.h"
#include "afxdialogex.h"
#include "tlhelp32.h"

#define	ID_TIMER_MONITOR	1
#define	ID_TIMER_COUNTER	2
#define	ID_TIME_SEC			1000
// CMonitorDlg �Ի���
extern CBasicSetDlg m_page1;
extern BOOL bool_StartTest;
extern BOOL bool_initTest;
extern CString strListSWPath[SOFTWARENUM];
extern CString cstr_pathCurrentDir;

IMPLEMENT_DYNAMIC(CMonitorDlg, CDialogEx)

CMonitorDlg::CMonitorDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CMonitorDlg::IDD, pParent)
{

	cstr_get3DMarkCycle = _T("");
	str_currentTime = _T("");
	uint_ExecutionNum = 0;
	int_counter = 0;
}

CMonitorDlg::~CMonitorDlg()
{
}

void CMonitorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_TESTPROG, c_list_testprog);
	DDX_Control(pDX, IDC_EDIT_COUNTER, c_edit_counter);
}


BEGIN_MESSAGE_MAP(CMonitorDlg, CDialogEx)
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CMonitorDlg ��Ϣ��������
void ScreenCapture(char filename[])
{
	CDC *pDC;//��ĻDC
	pDC = CDC::FromHandle(GetDC(NULL));//��ȡ��ǰ������ĻDC
	int BitPerPixel = pDC->GetDeviceCaps(BITSPIXEL);//�����ɫģʽ
	int Width = pDC->GetDeviceCaps(HORZRES);
	int Height = pDC->GetDeviceCaps(VERTRES);

	CDC memDC;//�ڴ�DC
	memDC.CreateCompatibleDC(pDC);

	CBitmap memBitmap, *oldmemBitmap;//��������Ļ���ݵ�bitmap
	memBitmap.CreateCompatibleBitmap(pDC, Width, Height);

	oldmemBitmap = memDC.SelectObject(&memBitmap);//��memBitmapѡ���ڴ�DC
	memDC.BitBlt(0, 0, Width, Height, pDC, 0, 0, SRCCOPY);//������Ļͼ���ڴ�DC

	//���´��뱣��memDC�е�λͼ���ļ�
	BITMAP bmp;
	memBitmap.GetBitmap(&bmp);//���λͼ��Ϣ

	FILE *fp;// = fopen(filename, "w+b");
	fopen_s(&fp, filename, "w+b");
	BITMAPINFOHEADER bih = { 0 };//λͼ��Ϣͷ
	bih.biBitCount = bmp.bmBitsPixel;//ÿ�������ֽڴ�С
	bih.biCompression = BI_RGB;
	bih.biHeight = bmp.bmHeight;//�߶�
	bih.biPlanes = 1;
	bih.biSize = sizeof(BITMAPINFOHEADER);
	bih.biSizeImage = bmp.bmWidthBytes * bmp.bmHeight;//ͼ�����ݴ�С
	bih.biWidth = bmp.bmWidth;//����

	BITMAPFILEHEADER bfh = { 0 };//λͼ�ļ�ͷ
	bfh.bfOffBits = sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);//��λͼ���ݵ�ƫ����
	bfh.bfSize = bfh.bfOffBits + bmp.bmWidthBytes * bmp.bmHeight;//�ļ��ܵĴ�С
	bfh.bfType = (WORD)0x4d42;

	fwrite(&bfh, 1, sizeof(BITMAPFILEHEADER), fp);//д��λͼ�ļ�ͷ

	fwrite(&bih, 1, sizeof(BITMAPINFOHEADER), fp);//д��λͼ��Ϣͷ

	byte * p = new byte[bmp.bmWidthBytes * bmp.bmHeight];//�����ڴ汣��λͼ����

	GetDIBits(memDC.m_hDC, (HBITMAP)memBitmap.m_hObject, 0, Height, p,
		(LPBITMAPINFO)&bih, DIB_RGB_COLORS);//��ȡλͼ����

	fwrite(p, 1, bmp.bmWidthBytes * bmp.bmHeight, fp);//д��λͼ����

	delete[] p;

	fclose(fp);

	memDC.SelectObject(oldmemBitmap);
}

BOOL CMonitorDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	
	//�б��ؼ���ȡ
	CRect listRect;
	CFont m_Font;
	//CString strListName[4];
	c_list_testprog.GetClientRect(&listRect);
	c_list_testprog.SetExtendedStyle(c_list_testprog.GetExtendedStyle() | LVS_EX_FULLROWSELECT);//| LVS_EX_GRIDLINES);

	c_list_testprog.InsertColumn(0, _T("Level"), LVCFMT_CENTER, listRect.Width() / 5, 0);
	c_list_testprog.InsertColumn(1, _T("Software Name"), LVCFMT_CENTER, 2 * listRect.Width() / 5, 1);
	c_list_testprog.InsertColumn(2, _T("Status"), LVCFMT_CENTER, 2 * listRect.Width() / 5, 2);

	c_list_testprog.DeleteAllItems();
	c_list_testprog.InsertItem(0, L"01");
	c_list_testprog.SetItemText(0, 1, L"N/A");
	c_list_testprog.SetItemText(0, 2, L"N/A");
	//c_edit_counter.SetWindowTextW(L"10");
	m_Font.CreatePointFont(360, L"Arial");
	c_edit_counter.SetFont(&m_Font);
	c_edit_counter.ShowWindow(SW_HIDE);
	bool_startMonitor = FALSE;
	int_counter = 15;
	SetTimer(ID_TIMER_MONITOR,ID_TIME_SEC,NULL);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣:  OCX ����ҳӦ���� FALSE
}
//��������������������
BOOL CMonitorDlg::SearchApplication(CString SWName,UINT LevelNum)
{
	CString cstr_Parameter;
	//CString str_currentTime; //��ȡϵͳʱ�� ����
	CTime tm;
	if (!PathIsDirectory(cstr_pathCurrentDir+L"\\LogFile"))//�ж�·���Ƿ����     
		CreateDirectory(cstr_pathCurrentDir + L"\\LogFile", NULL);//�½��ļ���
	tm = CTime::GetCurrentTime();
	str_currentTime = tm.Format(L"%Y%m%d_%H%M%S_");
	//cstr_currentDir = cstr_currentDir+L"\\"+str_currentTime;
	if (StrStr(SWName, L"3DMark"))
	{
		::GetPrivateProfileString(SW_PARAMETER, L"3DMarkCycle", L"1", cstr_get3DMarkCycle.GetBuffer(MAX_PATH), MAX_PATH, SW_CONFIG);
		cstr_get3DMarkCycle.ReleaseBuffer();
		cstr_Parameter = L"-runall -out=" + cstr_pathCurrentDir + L"\\LogFile\\" + str_currentTime + L"3DMarkFile.3dmark-result -audio=off -loop=" + cstr_get3DMarkCycle;
		if ((int)ShellExecute(NULL, L"open", strListSWPath[LevelNum], cstr_Parameter, NULL, SW_HIDE) <= 32)
			MessageBox(L"����3DMarkʧ�ܣ�", L"SoftwareShell", MB_ICONERROR);
		else
			c_list_testprog.SetItemText(LevelNum, 2, L"Running");
	}
	else if (StrStr(SWName, L"BurnInTest"))
	{
		if ((int)ShellExecute(NULL, L"open", strListSWPath[LevelNum], L"-R", NULL, SW_SHOWNA) <= 32)
			MessageBox(L"����BurnInTestʧ�ܣ�", L"SoftwareShell", MB_ICONERROR);
		else
			c_list_testprog.SetItemText(LevelNum, 2, L"Running");
	}
	else if (StrStr(SWName, L"StartMemTest"))
	{
		::WritePrivateProfileString(L"CONFIG", L"AUTOTEST", L"1", cstr_pathCurrentDir + L"\\StartMemTest\\OpenMemTS.ini");
		if ((int)ShellExecute(NULL, L"open", strListSWPath[LevelNum], NULL, NULL, SW_SHOWNA) <= 32)
			MessageBox(L"����StartMemTestʧ�ܣ�", L"SoftwareShell", MB_ICONERROR);
		else
			c_list_testprog.SetItemText(LevelNum, 2, L"Running");
	}
	else if (StrStr(SWName, L"Sleeper"))
	{
		
		//::GetPrivateProfileString(SW_PARAMETER, L"3DMarkCycle", L"1", cstr_getCFG.GetBuffer(MAX_PATH), MAX_PATH, SW_CONFIG);
		//cstr_getCFG.ReleaseBuffer();
		//cstr_Parameter = L"-D 30 -L D:\\x.log -N 100 -P 15 -S1100 -r1 31 -r2 32 -r3 33 -r4 34";
		cstr_Parameter.Format(L"-D %d -L %s -N %d -P 15 -S%d%d%d%d -r1 %d -r2 %d -r3 %d -r4 %d -E", ::GetPrivateProfileInt(SW_PARAMETER, L"CycleInterval", 30, SW_CONFIG),
			(cstr_pathCurrentDir + L"\\LogFile\\" + str_currentTime + L"SleeperFile.log"), ::GetPrivateProfileInt(SW_PARAMETER, L"NumberOfCycle", 1, SW_CONFIG),
			::GetPrivateProfileInt(SW_PARAMETER, L"S1Support", 0, SW_CONFIG), ::GetPrivateProfileInt(SW_PARAMETER, L"S2Support", 0, SW_CONFIG), ::GetPrivateProfileInt(SW_PARAMETER, L"S3Support", 0, SW_CONFIG),
			::GetPrivateProfileInt(SW_PARAMETER, L"S4Support", 0, SW_CONFIG), ::GetPrivateProfileInt(SW_PARAMETER, L"S1Duration", 30, SW_CONFIG), ::GetPrivateProfileInt(SW_PARAMETER, L"S2Duration", 30, SW_CONFIG),
			::GetPrivateProfileInt(SW_PARAMETER, L"S3Duration", 30, SW_CONFIG), ::GetPrivateProfileInt(SW_PARAMETER, L"S4Duration", 60, SW_CONFIG));
		if ((int)ShellExecute(NULL, L"runas", strListSWPath[LevelNum], cstr_Parameter, NULL, SW_SHOWNA) <= 32)
			MessageBox(L"����Sleeperʧ�ܣ�", L"SoftwareShell", MB_ICONERROR);
		else
			c_list_testprog.SetItemText(LevelNum, 2, L"Running");
	}
	
	return TRUE;
}
//�رղ�������
void CloseProgram(CString strProgram)
{
	HANDLE handle; //����CreateToolhelp32Snapshotϵͳ���վ��

	HANDLE handle1; //����Ҫ�������̾��

	handle = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);//���ϵͳ���վ��

	PROCESSENTRY32 *info; //����PROCESSENTRY32�ṹ��ָ

	//PROCESSENTRY32 �ṹ�� dwSize ��Ա���ó� sizeof(PROCESSENTRY32)

	info = new PROCESSENTRY32;

	info->dwSize = sizeof(PROCESSENTRY32);

	//����һ�� Process32First �������ӿ����л�ȡ�����б�

	Process32First(handle, info);

	//�ظ����� Process32Next��ֱ���������� FALSE Ϊֹ

	while (Process32Next(handle, info) != FALSE)

	{
		CString strTmp = info->szExeFile;     //ָ���������  

		if (strProgram.CompareNoCase(info->szExeFile) == 0)
		{
			//PROCESS_TERMINATE��ʾΪ����������,FALSE=�ɼ̳�,info->th32ProcessID=����ID   
			handle1 = OpenProcess(PROCESS_TERMINATE, FALSE, info->th32ProcessID);
			//��������   
			TerminateProcess(handle1, 0);
		}
	}
	delete info;
	CloseHandle(handle);

}

//��ؽ������������һ������
BOOL CMonitorDlg::ResultDetection(CString SWName)
{
	//������ʶ
	USES_CONVERSION;
	CTime tm ;
	CString str_CurTime;
	if (!PathIsDirectory(cstr_pathCurrentDir + L"\\LogFile"))//�ж�·���Ƿ����     
		CreateDirectory(cstr_pathCurrentDir + L"\\LogFile", NULL);//�½��ļ���
	if (StrStr(SWName, L"3DMark"))
	{
		if (PathFileExists(cstr_pathCurrentDir + L"\\LogFile\\" + str_currentTime + L"3DMarkFile-loop-" + cstr_get3DMarkCycle + L".3dmark-result"))
		{
			bool_startMonitor = FALSE;
			c_list_testprog.SetItemText(uint_ExecutionNum, 2, L"Tested");
			//uint_ExecutionNum++;
			c_edit_counter.ShowWindow(SW_SHOW);
			//int_counter = 15;
			SetTimer(ID_TIMER_COUNTER, ID_TIME_SEC, NULL);
		}
		else if (PathFileExists(cstr_pathCurrentDir + L"\\LogFile\\" + str_currentTime + L"3DMarkFile.3dmark-result"))
		{
			bool_startMonitor = FALSE;
			c_list_testprog.SetItemText(uint_ExecutionNum, 2, L"Tested");
			//uint_ExecutionNum++;
			//int_counter = 15;
			c_edit_counter.ShowWindow(SW_SHOW);
			SetTimer(ID_TIMER_COUNTER, ID_TIME_SEC, NULL);
		}
	}
	else if (StrStr(SWName, L"BurnInTest"))
	{
		CString cstr_burninResult;
		HWND hBurnInTestResult=::FindWindow(NULL, L"BurnInTest test result");
		if (hBurnInTestResult)
		{
			bool_startMonitor = FALSE;
			Sleep(2000);
			//uint_ExecutionNum++;
			//��ͼ
			tm = CTime::GetCurrentTime();
			str_CurTime = tm.Format(L"%Y%m%d_%H%M%S_");
			str_CurTime += L"BurnInTestResult.jpg";
			//����T2A��W2A��֧��ATL��MFC�е��ַ�
			char * pFileName = T2A(cstr_pathCurrentDir + L"\\LogFile\\" + str_CurTime);
			ScreenCapture(pFileName);
			//::SendMessage(hBurnInTestResult, WM_CLOSE, NULL, NULL);
			//::GetDlgItemText(hBurnInTestResult, 0x42F, cstr_burninResult.GetBuffer(20), 20);
			::SendDlgItemMessage(hBurnInTestResult, 0x42F, WM_GETTEXT, 20, (LPARAM)(LPCTSTR)cstr_burninResult);
			//cstr_burninResult.ReleaseBuffer();
			c_list_testprog.SetItemText(uint_ExecutionNum, 2, cstr_burninResult);

			Sleep(500);
			//�رղ���
			//CloseApplication(SWName);
			CloseProgram(L"bit.exe");
			c_edit_counter.ShowWindow(SW_SHOW);
			//int_counter = 15;
			SetTimer(ID_TIMER_COUNTER, ID_TIME_SEC, NULL);
		}
	}
	else if (StrStr(SWName, L"StartMemTest"))
	{
		CString cstr_memTestResult;
		HWND hMemTestResult = ::FindWindow(NULL, L"MemTestResult");
		if (hMemTestResult)
		{
			bool_startMonitor = FALSE;
			Sleep(1500);
			::GetDlgItemText(hMemTestResult, 0x414, cstr_memTestResult.GetBuffer(20), 20);
			cstr_memTestResult.ReleaseBuffer();
			c_list_testprog.SetItemText(uint_ExecutionNum, 2, cstr_memTestResult);
			//uint_ExecutionNum++;
			//��ͼ
			tm = CTime::GetCurrentTime();
			str_CurTime = tm.Format(L"%Y%m%d_%H%M%S_");
			str_CurTime += L"MemTestResult.jpg";
			
			//����T2A��W2A��֧��ATL��MFC�е��ַ�
			char * pFileName = T2A(cstr_pathCurrentDir + L"\\LogFile\\" + str_CurTime);
			ScreenCapture(pFileName);
			
			Sleep(500);
			//�رղ���
			CloseProgram(L"memTestPro.exe");
			CloseProgram(L"StartMemTest.exe");
			//int_counter = 15;
			c_edit_counter.ShowWindow(SW_SHOW);
			SetTimer(ID_TIMER_COUNTER, ID_TIME_SEC, NULL);
		}
	}
	else if (StrStr(SWName, L"Sleeper"))
	{
		CStdioFile csFile;
		CString cstr_sleeperResult;
		//CFileException cfException;
		if (csFile.Open(cstr_pathCurrentDir + L"\\LogFile\\" + str_currentTime + L"SleeperFile.log", CFile::typeText | CFile::modeRead | CFile::shareDenyNone, NULL))
		{
			//csFile.SeekToEnd();
			csFile.Seek(-256, 2);
			while (csFile.ReadString(cstr_sleeperResult))
			{
				if (_tcsstr(cstr_sleeperResult, L"Last cycle completed") != NULL)
				{
					bool_startMonitor = FALSE;
					c_list_testprog.SetItemText(uint_ExecutionNum, 2, L"Tested");
					//uint_ExecutionNum++;
					//��ͼ
					//Sleep(1000);
					tm = CTime::GetCurrentTime();
					str_CurTime = tm.Format(L"%Y%m%d_%H%M%S_");
					str_CurTime += L"SleeperResult.jpg";

					//����T2A��W2A��֧��ATL��MFC�е��ַ�
					char * pFileName = T2A(cstr_pathCurrentDir + L"\\LogFile\\" + str_CurTime);
					ScreenCapture(pFileName);
					//�رղ���
					//CloseApplication(SWName);
					//int_counter = 15;
					c_edit_counter.ShowWindow(SW_SHOW);
					SetTimer(ID_TIMER_COUNTER, ID_TIME_SEC, NULL);
					break;
				}
			}
			//setlocale(LC_CTYPE, "chs");//Ϊ������csFile.WriteString(strWriteData)д������
			//csFile.WriteString(strWriteData);
		}
		csFile.Close();
	}
	return TRUE;
}
void CMonitorDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO:  �ڴ�������Ϣ������������/�����Ĭ��ֵ
	int i;
	CString cstr_levelNum, cstr_counter;
	switch (nIDEvent)
	{
	case ID_TIMER_MONITOR:
		if (bool_StartTest && bool_initTest)
		{
			bool_initTest = FALSE;
			c_list_testprog.DeleteAllItems();
			for (i = 0; i < m_page1.c_listLevel.GetItemCount(); i++)
			{
				cstr_levelNum.Format(L"%02d", i + 1);
				c_list_testprog.InsertItem(i, cstr_levelNum);
				c_list_testprog.SetItemText(i, 1, m_page1.c_listLevel.GetItemText(i, 1));
				c_list_testprog.SetItemText(i, 2, L"Waitting");
			}
			uint_ExecutionNum = 0;
			SearchApplication(c_list_testprog.GetItemText(uint_ExecutionNum, 1), uint_ExecutionNum);
			bool_startMonitor = TRUE;
			//UpdateData();
		}
		if (bool_StartTest && bool_startMonitor)
		{
			//TIS_Trace(TEXT("���\n"));
			ResultDetection(c_list_testprog.GetItemText(uint_ExecutionNum, 1));
		}
		break;
	case ID_TIMER_COUNTER:
		if (int_counter >= 0)
		{
			cstr_counter.Format(L"%d",int_counter);
			c_edit_counter.SetWindowTextW(cstr_counter);
			int_counter--;
		}
		else
		{
			KillTimer(ID_TIMER_COUNTER);
			int_counter = 15;
			c_edit_counter.ShowWindow(SW_HIDE);
			uint_ExecutionNum++;
			if (uint_ExecutionNum < (UINT)c_list_testprog.GetItemCount())
			{
				SearchApplication(c_list_testprog.GetItemText(uint_ExecutionNum, 1), uint_ExecutionNum);
				bool_startMonitor = TRUE;
			}
			else
			{
				//ֹͣ����
				m_page1.bool_StartOrStop = !(m_page1.bool_StartOrStop);
				bool_StartTest = FALSE;
				bool_initTest = FALSE;
				bool_startMonitor = FALSE;
				m_page1.SetDlgItemTextW(IDC_BTN_STARTTEST, L"��ʼ����");
				if (::GetPrivateProfileInt(SW_PARAMETER, L"RunRebooter", 0, SW_CONFIG) == 1)
					ShellExecute(NULL, L"open", cstr_pathCurrentDir + L"\\Rebooter\\rebooter.exe", L"-Reboot", NULL, SW_SHOWNA);
			}
			
		}
		break;
	default:
		break;
	}
	CDialogEx::OnTimer(nIDEvent);
}
