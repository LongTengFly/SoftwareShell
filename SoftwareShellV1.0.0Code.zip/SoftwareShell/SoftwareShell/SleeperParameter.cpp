// SleeperParameter.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SoftwareShell.h"
#include "SleeperParameter.h"
#include "afxdialogex.h"

// CSleeperParameter �Ի���

IMPLEMENT_DYNAMIC(CSleeperParameter, CDialogEx)

CSleeperParameter::CSleeperParameter(CWnd* pParent /*=NULL*/)
	: CDialogEx(CSleeperParameter::IDD, pParent)
{

}

CSleeperParameter::~CSleeperParameter()
{
}

void CSleeperParameter::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CSleeperParameter, CDialogEx)
	ON_BN_CLICKED(IDOK, &CSleeperParameter::OnBnClickedOk)
END_MESSAGE_MAP()


// CSleeperParameter ��Ϣ��������
extern CString cstr_pathCurrentDir;
UINT arr_EditID[4] = { IDC_EDIT_S1, IDC_EDIT_S2, IDC_EDIT_S3, IDC_EDIT_S4 };
UINT arr_checkBoxID[4] = { IDC_CHECK_S1, IDC_CHECK_S2, IDC_CHECK_S3, IDC_CHECK_S4 };

BOOL CSleeperParameter::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	//������ʶ
	USES_CONVERSION;
	//����T2A��W2A��֧��ATL��MFC�е��ַ�
	CString cstr_sleeperPath;
	::GetPrivateProfileString(SW_PATH, L"Sleeper", cstr_pathCurrentDir + L"\\Sleeper\\Sleeper.exe", cstr_sleeperPath.GetBuffer(MAX_PATH), MAX_PATH, SW_CONFIG);
	cstr_sleeperPath.ReleaseBuffer();
	cstr_sleeperPath.Insert(0, L"\"");
	cstr_sleeperPath.Append(L"\" -O");
	//char * pFileName = T2A(cstr_pathCurrentDir + L"\\Sleeper\\Sleeper.exe -O");
	//char * pFileName = T2A(L"\"C:\\Users\\FLY\\Desktop\\SoftwareShell ����\\Sleeper\\Sleeper.exe\" -O");
	char * pFileName = T2A(cstr_sleeperPath);
	int sleeperSupport = system(pFileName);
	
	//TIS_Trace(TEXT("state:%d\npath:%S"), sleeperSupport, pFileName);
	CString cstr_getSleepDuration;
	CString cstr_SleepLevel;
	
	for (int i = 0; i < 4;i++)
	{
		((CButton *)GetDlgItem(arr_checkBoxID[i]))->EnableWindow(sleeperSupport % 2);
		((CButton *)GetDlgItem(arr_EditID[i]))->EnableWindow(sleeperSupport % 2);
		cstr_SleepLevel.Format(L"S%dDuration",i+1);
		
		::GetPrivateProfileString(SW_PARAMETER, cstr_SleepLevel, L"30", cstr_getSleepDuration.GetBuffer(MAX_PATH), MAX_PATH, SW_CONFIG);
		cstr_getSleepDuration.ReleaseBuffer();
		if (i == 3 && (::GetPrivateProfileInt(SW_PARAMETER, cstr_SleepLevel, 30, SW_CONFIG))<60)
			((CButton *)GetDlgItem(arr_EditID[i]))->SetWindowTextW(L"60");
		else
			((CButton *)GetDlgItem(arr_EditID[i]))->SetWindowTextW(cstr_getSleepDuration);
		//::GetPrivateProfileInt();
		cstr_SleepLevel.Format(L"S%dSupport", i + 1);
		if (sleeperSupport % 2 == 0)
			((CButton *)GetDlgItem(arr_checkBoxID[i]))->SetCheck(FALSE);
		else
			((CButton *)GetDlgItem(arr_checkBoxID[i]))->SetCheck(::GetPrivateProfileInt(SW_PARAMETER, cstr_SleepLevel, TRUE, SW_CONFIG));
		sleeperSupport = sleeperSupport / 2;
	}
	::GetPrivateProfileString(SW_PARAMETER, L"NumberOfCycle", L"1", cstr_getSleepDuration.GetBuffer(MAX_PATH), MAX_PATH, SW_CONFIG);
	cstr_getSleepDuration.ReleaseBuffer();
	((CButton *)GetDlgItem(IDC_EDIT_CYCLENUM))->SetWindowTextW(cstr_getSleepDuration);
	::GetPrivateProfileString(SW_PARAMETER, L"CycleInterval", L"30", cstr_getSleepDuration.GetBuffer(MAX_PATH), MAX_PATH, SW_CONFIG);
	cstr_getSleepDuration.ReleaseBuffer();
	((CButton *)GetDlgItem(IDC_ET_INTERVAL))->SetWindowTextW(cstr_getSleepDuration);

	::SetWindowPos(GetSafeHwnd(), HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);//SWP_DRAWFRAME | 
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣:  OCX ����ҳӦ���� FALSE
}


void CSleeperParameter::OnBnClickedOk()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	CString cstr_mTemp;
	CString cstr_SleepLevel;
	for (int i = 0; i < 4; i++)
	{
		cstr_SleepLevel.Format(L"S%dDuration", i + 1);
		GetDlgItem(arr_EditID[i])->GetWindowText(cstr_mTemp);
		::WritePrivateProfileString(SW_PARAMETER, cstr_SleepLevel, cstr_mTemp, SW_CONFIG);
		cstr_SleepLevel.Format(L"S%dSupport", i + 1);
		//arr_checkBoxID
		if(((CButton *)GetDlgItem(arr_checkBoxID[i]))->GetState()==1)
			::WritePrivateProfileString(SW_PARAMETER, cstr_SleepLevel, L"1", SW_CONFIG);
		else
			::WritePrivateProfileString(SW_PARAMETER, cstr_SleepLevel, L"0", SW_CONFIG);
	}
	GetDlgItem(IDC_EDIT_CYCLENUM)->GetWindowText(cstr_mTemp);
	::WritePrivateProfileString(SW_PARAMETER, L"NumberOfCycle", cstr_mTemp, SW_CONFIG);
	GetDlgItem(IDC_ET_INTERVAL)->GetWindowText(cstr_mTemp);
	::WritePrivateProfileString(SW_PARAMETER, L"CycleInterval", cstr_mTemp, SW_CONFIG);
	CDialogEx::OnOK();
}
