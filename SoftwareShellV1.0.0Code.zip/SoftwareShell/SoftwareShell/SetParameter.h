#pragma once


// CSetParameter �Ի���

class CSetParameter : public CDialogEx
{
	DECLARE_DYNAMIC(CSetParameter)

public:
	CSetParameter(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CSetParameter();

// �Ի�������
	enum { IDD = IDD_DLG_MSGBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	virtual BOOL OnInitDialog();
	CString cstr_CycleNum;
};
