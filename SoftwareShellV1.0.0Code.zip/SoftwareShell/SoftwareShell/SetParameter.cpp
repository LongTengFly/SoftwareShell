// SetParameter.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SoftwareShell.h"
#include "SetParameter.h"
#include "afxdialogex.h"


// CSetParameter �Ի���

IMPLEMENT_DYNAMIC(CSetParameter, CDialogEx)

CSetParameter::CSetParameter(CWnd* pParent /*=NULL*/)
	: CDialogEx(CSetParameter::IDD, pParent)
{

	cstr_CycleNum = _T("");
}

CSetParameter::~CSetParameter()
{
}

void CSetParameter::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CSetParameter, CDialogEx)
	ON_BN_CLICKED(IDOK, &CSetParameter::OnBnClickedOk)
END_MESSAGE_MAP()


// CSetParameter ��Ϣ��������


void CSetParameter::OnBnClickedOk()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	//CString cstr_CycleNum;
	GetDlgItem(IDC_EDIT_CYCLE)->GetWindowText(cstr_CycleNum);
	if (!cstr_CycleNum.IsEmpty())
		::WritePrivateProfileString(SW_PARAMETER, L"3DMarkCycle", cstr_CycleNum, SW_CONFIG);
	CDialogEx::OnOK();
}


BOOL CSetParameter::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	::GetPrivateProfileString(SW_PARAMETER, L"3DMarkCycle", L"1", cstr_CycleNum.GetBuffer(MAX_PATH), MAX_PATH, SW_CONFIG);
	cstr_CycleNum.ReleaseBuffer();
	GetDlgItem(IDC_EDIT_CYCLE)->SetWindowText(cstr_CycleNum);
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣:  OCX ����ҳӦ���� FALSE
}
